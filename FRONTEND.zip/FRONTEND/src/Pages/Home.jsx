import React from 'react'

const Home = () => {
  return (
    <>
      <h1>HOME PAGE</h1>
    </>
  )
}

export default Home
