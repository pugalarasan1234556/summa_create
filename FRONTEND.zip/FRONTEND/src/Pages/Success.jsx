import React from 'react'

const Success = () => {
  return (
    <>
      <h1>Success PAGE</h1>
    </>
  )
}

export default Success
